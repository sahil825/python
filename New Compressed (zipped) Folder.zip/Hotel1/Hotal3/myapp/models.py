from django.db import models

# Create your models here.
from django.db import models
from django.utils import timezone

# Create your models here.
class Reservation(models.Model):
	Name = models.CharField(max_length=200)
	Phone_no = models.IntegerField(default=0)
	Email = models.EmailField(max_length=70,blank=True)
	Check_In_date = models.DateTimeField(default=timezone.now)
	Check_out_date = models.DateTimeField(default=timezone.now)
	Adults = models.IntegerField(default=0)
	Children = models.IntegerField(default=0)
	No_Of_Rooms = models.IntegerField(default=0)
	published_date = models.DateTimeField(blank=True, null=True)
