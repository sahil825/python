from django.shortcuts import render
from django.core.mail import send_mail  # for send mail
from django.conf import settings  #  for send mail setting
from django.http import HttpResponse
# Create your views here.
def index(request):
	return render(request, 'index.html', {})

def about(request):
	return render(request, 'about.html', {})

def contact(request):
	return render(request, 'contact.html', {})

def gallery(request):
	return render(request, 'gallery.html', {})

def reservation(request):
	return render(request, 'reservation.html', {})

def room(request):
	return render(request, 'room.html', {})

def enquiry_data(request):
	name = request.POST.get("name", "default")
	mobile = request.POST.get("mobile_no", "default")
	email = request.POST.get("email", "default")
	sub = request.POST.get("sub", "default")
	mess = request.POST.get("msg", "default")
	subject = sub
	msg     = "Name: "+name +"\n"+"Mobile NO :"+mobile +"\n"+ "email : "+email +"\n"+ "message : "+mess
	to      = "kaur04085@gmail.com"     
	res     = send_mail(subject,msg,settings.EMAIL_HOST_USER, [to])

	return HttpResponse("<h1>Thanks for enquiry . Pleas <a href ='/'> click here </a> to go home</h1>")


def res_data(request):
	name = request.POST.get("name", "default")
	mobile = request.POST.get("mobileno", "default")
	email = request.POST.get("email", "default")
	checkin = request.POST.get("checkin", "default")
	checkout = request.POST.get("checkout", "default")
	adult = request.POST.get("adult", "default")
	child = request.POST.get("child", "default")
	roomno = request.POST.get("roomno", "default")
	sub = request.POST.get("sub", "default")
	print(name,mobile,email,checkin,checkout,adult,child,roomno)
	subject= sub
	msg     = "Name: "+name +"\n"+"Mobile NO :"+mobile +"\n"+ "email : "+email +"\n"+ "Check_in : "+checkin +"\n"+ "Check_out : "+checkout+"\n"+ "Adult : "+adult+"\n"+ "Children : "+child+"\n"+ "Room_no: "+roomno
	to      = "ajeetsaini0102@gmail.com"     
	res     = send_mail(subject,msg,settings.EMAIL_HOST_USER, [to])
	return HttpResponse("<h1>Thanks for checking . Pleas <a href ='/'> click here </a> to go home</h1>")
